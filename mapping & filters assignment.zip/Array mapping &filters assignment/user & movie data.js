//part-1 (User data array manipulations)

let users = [
    { name: "Aarav", age: 15, gender: "Male", location: "Delhi" },
    { name: "Aanya", age: 10, gender: "Female", location: "Mumbai" },
    { name: "Arjun", age: 22, gender: "Male", location: "Bangalore" },
    { name: "Avni", age: 28, gender: "Female", location: "Chennai" },
    { name: "Advait", age: 15, gender: "Male", location: "Kolkata" },
    { name: "Ananya", age: 29, gender: "Female", location: "Hyderabad" },
    { name: "Amit", age: 12, gender: "Male", location: "Pune" },
    { name: "Aditi", age: 17, gender: "Female", location: "Ahmedabad" },
    { name: "Aryan", age: 31, gender: "Male", location: "Jaipur" },
    { name: "Anika", age: 16, gender: "Female", location: "Lucknow" },
    { name: "Arun", age: 13, gender: "Male", location: "Chandigarh" },
    { name: "Alia", age: 24, gender: "Female", location: "Bhopal" },
    { name: "Akshay", age: 28, gender: "Male", location: "Indore" },
    { name: "Anushka", age: 29, gender: "Female", location: "Nagpur" },
    { name: "Ayush", age: 16, gender: "Male", location: "Surat" },
  ];
  //console.log(users);
  //1.3
function isAdult(user) {
    if (user && user.age && typeof user.age === 'number') {
      return user.age >= 18;
    } else {
      return false;
    }
  }
  let adults = users.map(isAdult)
   //  console.log(adults);
//1.4
  let adultUser = users.filter(isAdult)
    // console.log(adultUser);
//1.5
let usersfullname= users.map((user)=>{
  return user.name +" "+ user.location;
})
 //console.log(usersfullname)
//1.6
let userNames = users.map((user)=>{
  return user.name;
})
//console.log(userNames);


//part-2 (Chaining user data operations)

function filterByGender(user) {
  if (user.gender=="Female" || user.gender=="Male") {
    return true;
  } else {
    return false;
  }
}
//2.1
 let filteredUsers = users.map(filterByGender)
  //console.log(filteredUsers);
//2.a & 2.b
let femaleUsers = users.filter((user)=>{
  return user.gender=="Female";
}).map((user)=>{
  return user.name;
})
//console.log(femaleUsers);

// part-3(Movie data array manipulations)
let movies = [
  { title: "The Shawshank Redemption", genre: "Drama", year: 1994, rating: 9.3 },
  { title: "The Godfather", genre: "Crime", year: 1972, rating: 9.2 },
  { title: "The Dark Knight", genre: "Action", year: 2008, rating: 9.0 },
  { title: "Pulp Fiction", genre: "Crime", year: 1994, rating: 8.9 },
  { title: "Schindler's List", genre: "Biography", year: 1993, rating: 8.9 },
  { title: "Forrest Gump", genre: "Drama", year: 1994, rating: 8.8 },
  { title: "The Matrix", genre: "Action", year: 1999, rating: 8.7 },
  { title: "Titanic", genre: "Romance", year: 1997, rating: 7.8 },
  { title: "Inception", genre: "Action", year: 2010, rating: 8.8 },
  { title: "The Lord of the Rings: The Fellowship of the Ring", genre: "Adventure", year: 2001, rating: 8.8 }
];
//console.log(movies);

//part-4(Chaining movie data operations)
//4.1
function filterByGenre(movie){
  if ( movie.genre=="Action"||movie.genre =="Drama") {
    return true;
  } else {
    return false;
  }
}
let filteredgenre = movies.map(filterByGenre)
  //console.log(filteredgenre);
//4.2
let actionMovies = movies.filter((movie)=>{
  return movie.genre=="Action";
})
//console.log(actionMovies);
//4.3
let movieTitles = movies.map((movie)=>{
  if(movie.genre=="Action"){
    return movie.title;
  } else{
    return 0;
  }
})
//console.log(movieTitles)

//part-5(Integration and output)
let combinedResults={
  AdultUser:adultUser,
  UserNames:userNames,
  FemaleUsers:femaleUsers,
  MovieTitles:movieTitles
}
console.log(combinedResults)